package avaliacao2;

public class NotFoundProductException {

}

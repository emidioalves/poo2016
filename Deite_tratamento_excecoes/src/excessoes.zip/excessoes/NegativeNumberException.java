package excessoes;

public class NegativeNumberException extends Exception{
	
	public NegativeNumberException(){
	super("Não aceita valores negativos");
}
}

